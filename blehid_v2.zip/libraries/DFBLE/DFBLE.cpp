#include "Arduino.h"
#include "DFBLE.h"
void DFBLEClass::init(void)
{
	return;
}

void DFBLEClass::press_key(uint8_t key_value)
{
	Serial1.print("AT+KEY=");Serial1.print(key_value,DEC);Serial1.println();
}
void DFBLEClass::press_key(uint8_t key_value1,uint8_t key_value2)
{
	Serial1.print("AT+KEY=");Serial1.print(key_value1,DEC);Serial1.print("+");Serial1.print(key_value2,DEC);Serial1.println();
}
void DFBLEClass::press_key(uint8_t key_value1,uint8_t key_value2,uint8_t key_value3)
{
	Serial1.print("AT+KEY=");Serial1.print(key_value1,DEC);Serial1.print("+");Serial1.print(key_value2,DEC);Serial1.print("+");Serial1.print(key_value3,DEC);Serial1.println();
}
DFBLEClass BLE;