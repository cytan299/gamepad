#ifndef __DFBLE_H
#define __DFBLE_H

#include <inttypes.h>
#include "BLEHID.h"
class DFBLEClass
{
  public:
    void init(void);
    void press_key(uint8_t key_value);
    void press_key(uint8_t key_value1,uint8_t key_value2);
    void press_key(uint8_t key_value1,uint8_t key_value2,uint8_t key_value3);
};

extern DFBLEClass BLE;

#endif